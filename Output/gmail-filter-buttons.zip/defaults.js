const DEFAULT_FILTERS = [
  {
    name: "Action Needed",
    query: "is:inbox -category:promotions -category:social -category:updates -category:forums",
    enabled: true,
    builtin: true,
    group: "standard"
  },
  {
    name: "Today",
    query: "newer_than:1d",
    enabled: true,
    builtin: true,
    group: "standard"
  },
  {
    name: "This Week",
    query: "newer_than:7d",
    enabled: true,
    builtin: true,
    group: "standard"
  },
  {
    name: "User Labels",
    query: "has:userlabels in:inbox",
    enabled: true,
    builtin: true,
    group: "standard"
  },
  {
    name: "Attachments",
    query: "has:attachment",
    enabled: false,
    builtin: true,
    group: "standard"
  },
  {
    name: "Large Attachments",
    query: "has:attachment larger:10m",
    enabled: false,
    builtin: true,
    group: "standard"
  },
  {
    name: "Newsletters",
    query: "\"unsubscribe\" OR category:promotions",
    enabled: false,
    builtin: true,
    group: "standard"
  },
  {
    name: "Human Mail",
    query: "is:inbox -from:(no-reply@ noreply@ notifications@)",
    enabled: false,
    builtin: true,
    group: "standard"
  },
  {
    name: "No-Reply Senders",
    query: "from:(no-reply@ OR noreply@ OR notifications@)",
    enabled: false,
    builtin: true,
    group: "standard"
  },
  {
    name: "Older Than 1 Year",
    query: "older_than:1y",
    enabled: false,
    builtin: true,
    group: "standard"
  },
  {
    name: "Unread in Labels",
    query: "has:userlabels is:unread",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Emails With Google Docs",
    query: "\"docs.google.com\"",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Emails With Drive Links",
    query: "\"drive.google.com\"",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Muted Threads",
    query: "is:muted",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Sent But No Reply Likely",
    query: "in:sent -category:promotions -category:social -from:(no-reply@ noreply@ notifications@)",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Unread + Not Promotions",
    query: "is:unread -category:promotions",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Unread + Human Mail",
    query: "is:unread -from:(no-reply@ noreply@ notifications@)",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Emails With Calendar Links",
    query: "\"calendar\" OR \"schedule\" OR \"book a call\"",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Emails With PDF Attachments",
    query: "has:attachment filename:pdf",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "Emails With Images",
    query: "has:attachment filename:(jpg OR jpeg OR png)",
    enabled: false,
    builtin: true,
    group: "power"
  },
  {
    name: "No Labels Applied",
    query: "-has:userlabels in:inbox",
    enabled: false,
    builtin: true,
    group: "power"
  }
];

const DEFAULTS_VERSION = 3;

const REMOVED_FILTERS = new Set([
  "Unread + Important",
  "Starred",
  "Drafts Needing Attention"
]);

const GROUP_ORDER = { custom: 0, standard: 1, power: 2 };

function sortFilters(filters) {
  return [...filters].sort((a, b) => {
    if (!!a.enabled !== !!b.enabled) return a.enabled ? -1 : 1;
    return (GROUP_ORDER[a.group] ?? 9) - (GROUP_ORDER[b.group] ?? 9);
  });
}

function mergeWithDefaults(stored, options) {
  const resetBuiltinEnabled = !!(options && options.resetBuiltinEnabled);
  const filters = (Array.isArray(stored) ? stored : [])
    .filter((filter) => filter && !REMOVED_FILTERS.has(filter.name))
    .map((filter) => ({ ...filter }));
  const byName = new Map(filters.map((filter) => [filter.name, filter]));

  DEFAULT_FILTERS.forEach((def) => {
    const existing = byName.get(def.name);
    if (!existing) {
      filters.push({ ...def });
      return;
    }

    existing.builtin = true;
    existing.group = existing.group || def.group;
    if (resetBuiltinEnabled || typeof existing.enabled !== "boolean") {
      existing.enabled = def.enabled;
    }
    if (!existing.query) {
      existing.query = def.query;
    }
  });

  filters.forEach((filter) => {
    if (typeof filter.enabled !== "boolean") {
      filter.enabled = true;
    }
    if (!filter.group) {
      filter.group = filter.builtin ? "standard" : "custom";
    }
  });

  return sortFilters(filters);
}

function getEnabledFilters(filters) {
  return (filters || []).filter((filter) => filter && filter.enabled && filter.query);
}

function readManagedFilters(callback) {
  chrome.storage.sync.get({ filters: [], defaultsVersion: 0 }, (data) => {
    const resetBuiltinEnabled = data.defaultsVersion !== DEFAULTS_VERSION;
    const filters = mergeWithDefaults(data.filters || [], { resetBuiltinEnabled });
    if (resetBuiltinEnabled) {
      chrome.storage.sync.set({ filters, defaultsVersion: DEFAULTS_VERSION }, () => callback(filters));
      return;
    }
    callback(filters);
  });
}
